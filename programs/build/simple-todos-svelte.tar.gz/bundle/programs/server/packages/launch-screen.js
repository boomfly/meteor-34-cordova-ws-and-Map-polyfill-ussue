Package["core-runtime"].queue("launch-screen",function () {/* Package-scope variables */
var LaunchScreen;



/* Exports */
return {
  export: function () { return {
      LaunchScreen: LaunchScreen
    };}
}});
